const menuBtn = document.querySelector('.menu-btn');
const navLinks = document.querySelector('.nav-links');
const quoteForm = document.getElementById('quoteForm');
const formNote = document.getElementById('formNote');

menuBtn.addEventListener('click', () => navLinks.classList.toggle('open'));
document.querySelectorAll('.nav-links a').forEach(link =>
  link.addEventListener('click', () => navLinks.classList.remove('open'))
);

quoteForm.addEventListener('submit', (e) => {
  e.preventDefault();
  formNote.textContent = "Thanks! Your enquiry is ready to be connected to the company's email or WhatsApp.";
  quoteForm.reset();
});

document.getElementById('year').textContent = new Date().getFullYear();
